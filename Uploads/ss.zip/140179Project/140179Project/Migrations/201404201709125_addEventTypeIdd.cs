namespace _140179Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class addEventTypeIdd : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.EventModels", "TypeEvent_ID", "dbo.TypeEvents");
            DropIndex("dbo.EventModels", new[] { "TypeEvent_ID" });
            RenameColumn(table: "dbo.EventModels", name: "TypeEvent_ID", newName: "TypeEventId");
            AlterColumn("dbo.EventModels", "TypeEventId", c => c.Int(nullable: false));
            CreateIndex("dbo.EventModels", "TypeEventId");
            AddForeignKey("dbo.EventModels", "TypeEventId", "dbo.TypeEvents", "ID", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.EventModels", "TypeEventId", "dbo.TypeEvents");
            DropIndex("dbo.EventModels", new[] { "TypeEventId" });
            AlterColumn("dbo.EventModels", "TypeEventId", c => c.Int());
            RenameColumn(table: "dbo.EventModels", name: "TypeEventId", newName: "TypeEvent_ID");
            CreateIndex("dbo.EventModels", "TypeEvent_ID");
            AddForeignKey("dbo.EventModels", "TypeEvent_ID", "dbo.TypeEvents", "ID");
        }
    }
}
