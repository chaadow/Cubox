namespace _140179Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Relation : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Relationships",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        UserId = c.String(nullable: false, maxLength: 128),
                        UserFriendId = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.AspNetUsers", t => t.UserId)
                .ForeignKey("dbo.AspNetUsers", t => t.UserFriendId)
                .Index(t => t.UserId)
                .Index(t => t.UserFriendId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Relationships", "UserFriendId", "dbo.AspNetUsers");
            DropForeignKey("dbo.Relationships", "UserId", "dbo.AspNetUsers");
            DropIndex("dbo.Relationships", new[] { "UserFriendId" });
            DropIndex("dbo.Relationships", new[] { "UserId" });
            DropTable("dbo.Relationships");
        }
    }
}
