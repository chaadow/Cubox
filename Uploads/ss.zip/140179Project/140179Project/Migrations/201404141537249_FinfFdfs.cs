namespace _140179Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class FinfFdfs : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.EventModels",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Address = c.String(),
                        Status_ID = c.Int(),
                        TypeEvent_ID = c.Int(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Status", t => t.Status_ID)
                .ForeignKey("dbo.TypeEvents", t => t.TypeEvent_ID)
                .Index(t => t.Status_ID)
                .Index(t => t.TypeEvent_ID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.EventModels", "TypeEvent_ID", "dbo.TypeEvents");
            DropForeignKey("dbo.EventModels", "Status_ID", "dbo.Status");
            DropIndex("dbo.EventModels", new[] { "TypeEvent_ID" });
            DropIndex("dbo.EventModels", new[] { "Status_ID" });
            DropTable("dbo.EventModels");
        }
    }
}
