namespace _140179Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class seeddata : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
