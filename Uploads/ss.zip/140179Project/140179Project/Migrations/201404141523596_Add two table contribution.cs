namespace _140179Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Addtwotablecontribution : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Contributions",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Quantity = c.String(),
                        ContributionType_ID = c.Int(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.ContributionTypes", t => t.ContributionType_ID)
                .Index(t => t.ContributionType_ID);
            
            CreateTable(
                "dbo.ContributionTypes",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        name = c.String(),
                    })
                .PrimaryKey(t => t.ID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Contributions", "ContributionType_ID", "dbo.ContributionTypes");
            DropIndex("dbo.Contributions", new[] { "ContributionType_ID" });
            DropTable("dbo.ContributionTypes");
            DropTable("dbo.Contributions");
        }
    }
}
