namespace _140179Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class addStatusId : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.EventModels", "Status_ID", "dbo.Status");
            DropIndex("dbo.EventModels", new[] { "Status_ID" });
            RenameColumn(table: "dbo.EventModels", name: "Status_ID", newName: "StatusId");
            AlterColumn("dbo.EventModels", "StatusId", c => c.Int(nullable: false));
            CreateIndex("dbo.EventModels", "StatusId");
            AddForeignKey("dbo.EventModels", "StatusId", "dbo.Status", "ID", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.EventModels", "StatusId", "dbo.Status");
            DropIndex("dbo.EventModels", new[] { "StatusId" });
            AlterColumn("dbo.EventModels", "StatusId", c => c.Int());
            RenameColumn(table: "dbo.EventModels", name: "StatusId", newName: "Status_ID");
            CreateIndex("dbo.EventModels", "Status_ID");
            AddForeignKey("dbo.EventModels", "Status_ID", "dbo.Status", "ID");
        }
    }
}
