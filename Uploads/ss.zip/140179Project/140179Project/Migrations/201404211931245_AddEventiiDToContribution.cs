namespace _140179Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddEventiiDToContribution : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Contributions", "EventModelId", c => c.Int(nullable: false));
            CreateIndex("dbo.Contributions", "EventModelId");
            AddForeignKey("dbo.Contributions", "EventModelId", "dbo.EventModels", "ID", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Contributions", "EventModelId", "dbo.EventModels");
            DropIndex("dbo.Contributions", new[] { "EventModelId" });
            DropColumn("dbo.Contributions", "EventModelId");
        }
    }
}
