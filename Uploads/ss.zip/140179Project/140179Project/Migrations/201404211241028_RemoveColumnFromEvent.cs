namespace _140179Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class RemoveColumnFromEvent : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.EventModels", "UserId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.EventModels", "UserId", c => c.Int(nullable: false));
        }
    }
}
