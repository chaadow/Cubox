using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using _140179Project.Models;

namespace _140179Project.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<_140179Project.Models.ApplicationDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
        }

        protected override void Seed(_140179Project.Models.ApplicationDbContext context)
        {
       
            var status = new List<Status>{
                new Status { name = "Pending" },
                new Status { name = "Open" },
                new Status { name = "Closed" }
            };
            status.ForEach(s => context.Statuses.AddOrUpdate(p => p.name, s));
            context.SaveChanges();

            var typeevent = new List<TypeEvent>{
                new TypeEvent() { TypeName = "Party" },
                new TypeEvent() { TypeName = "Brunch" },
                new TypeEvent() { TypeName = "Microsoft" }
            };
            typeevent.ForEach(s => context.TypeEvents.AddOrUpdate(t => t.TypeName, s));
            context.SaveChanges();
            
            var UserManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(context));
            var RoleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(context));

            string name = "Admin";
            string password = "123456";
           
            var idManager = new IdentityManager();
             idManager.CreateRole("Admin");
         
             idManager.CreateRole("Website Admin");
       
             idManager.CreateRole("User");






             if (!RoleManager.RoleExists(name))
             {
                 var roleresult = RoleManager.Create(new IdentityRole(name));
             }

             //Create User=Admin with password=123456
             var user = new ApplicationUser();
             user.UserName = name;
             user.Email = "admin@admin.com";
             user.FirstName = "admin";
             user.LastName = "lastname";
             var adminresult = UserManager.Create(user, password);

             //Add User Admin to Role Admin
             if (adminresult.Succeeded)
             {
                 Debug.WriteLine("My debug string here SUCEED");
                 var result = UserManager.AddToRole(user.Id, name);
             }
             else
             {
                 Debug.WriteLine("My debug string here FAIL");
             }
         //  idManager.AddUserToRole(user.Id, "Admin");
            var newUser = new ApplicationUser();

            newUser.UserName = "cbourguiba";
            newUser.FirstName = "Chedli";
            newUser.LastName = "Bourguib";
            newUser.Email = "chedli.bourguiba@supinfo.com";
      
  
            
            var blabla =  UserManager.Create(newUser, "blabla");

          
       
            //idManager.AddUserToRole(newUser.Id, "Admin");
            
            
  
            // idManager.AddUserToRole(newUser.Id, "Website Admin");
           
  
         //  idManager.AddUserToRole(newUser.Id, "User");
          
        }
       
        }
    }

