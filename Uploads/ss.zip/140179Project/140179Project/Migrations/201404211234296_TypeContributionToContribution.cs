namespace _140179Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class TypeContributionToContribution : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Contributions", "ContributionType_ID", "dbo.ContributionTypes");
            DropIndex("dbo.Contributions", new[] { "ContributionType_ID" });
            RenameColumn(table: "dbo.Contributions", name: "ContributionType_ID", newName: "ContributionTypeId");
            AddColumn("dbo.EventModels", "UserId", c => c.Int(nullable: false));
            AlterColumn("dbo.Contributions", "ContributionTypeId", c => c.Int(nullable: false));
            CreateIndex("dbo.Contributions", "ContributionTypeId");
            AddForeignKey("dbo.Contributions", "ContributionTypeId", "dbo.ContributionTypes", "ID", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Contributions", "ContributionTypeId", "dbo.ContributionTypes");
            DropIndex("dbo.Contributions", new[] { "ContributionTypeId" });
            AlterColumn("dbo.Contributions", "ContributionTypeId", c => c.Int());
            DropColumn("dbo.EventModels", "UserId");
            RenameColumn(table: "dbo.Contributions", name: "ContributionTypeId", newName: "ContributionType_ID");
            CreateIndex("dbo.Contributions", "ContributionType_ID");
            AddForeignKey("dbo.Contributions", "ContributionType_ID", "dbo.ContributionTypes", "ID");
        }
    }
}
