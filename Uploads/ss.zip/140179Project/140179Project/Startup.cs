﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(_140179Project.Startup))]
namespace _140179Project
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
