﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using Microsoft.Ajax.Utilities;
using _140179Project.Models;

namespace _140179Project
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            
           Debug.WriteLine("HELLOOOOOOOOOOOOOO");
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            Debug.WriteLine("Hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
           // Database.SetInitializer(new MyDbInitializer());
            Debug.WriteLine("thannnnnnnnnnnnnnnnnnnks");

        }
    }
}
