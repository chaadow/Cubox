﻿using System.Diagnostics;
using System.Web;
using System.Web.Mvc;

namespace _140179Project
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            Debug.WriteLine("HELLOOOOOOOOOOOOOO");
            filters.Add(new HandleErrorAttribute());
        }
    }
}
