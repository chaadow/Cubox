﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace _140179Project.Models
{
    public class Status
    {
        public int ID { get; set; }
        public string name { get; set; }
        public virtual List<EventModel> EventModels { get; set; }
    }
}