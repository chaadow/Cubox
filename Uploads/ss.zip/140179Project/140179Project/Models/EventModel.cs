﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls.Expressions;
using Newtonsoft.Json;

namespace _140179Project.Models
{
    public class EventModel
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Description { get; set; }
        public DateTime DateTime { get; set; }

        public int TypeEventId { get; set; }
        public int StatusId { get; set; }

      



        public virtual TypeEvent TypeEvent { get; set; }
       
        public virtual Status Status { get; set; }

        public virtual ApplicationUser ApplicationUser { get; set; }

        public virtual List<Contribution> Contributions { get; set; }







    }
}