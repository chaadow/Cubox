﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace _140179Project.Models
{
    public class Contribution
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Quantity { get; set; }
        public int ContributionTypeId { get; set; }
        public int EventModelId { get; set; }

        public virtual ContributionType ContributionType { get; set; }
        public virtual EventModel EventModel { get; set; }





    }
}