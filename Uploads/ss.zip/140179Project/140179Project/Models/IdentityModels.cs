﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Runtime.Remoting.Contexts;
using System.Security.Cryptography.X509Certificates;
using System.Web.Services.Description;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;

namespace _140179Project.Models
{
    // You can add profile data for the user by adding more properties to your ApplicationUser class, please visit http://go.microsoft.com/fwlink/?LinkID=317594 to learn more.
    public class ApplicationUser : IdentityUser
    {
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }

        [Required]
        public string Email { get; set; }
        public virtual List<EventModel> EventModels { get; set; }
        public virtual List<Relationship> Users { get; set; }
        public virtual List<Relationship> UserFriends { get; set; }


    }

    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext()
            : base("DefaultConnection")
        {
            
        }

        

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        
            modelBuilder.Entity<Relationship>()
                        .HasRequired(r => r.User)
                        .WithMany(u => u.Users)
                        .HasForeignKey(r => r.UserId)
                        .WillCascadeOnDelete(false);

            modelBuilder.Entity<Relationship>()
                        .HasRequired(r => r.UserFriend)
                        .WithMany( u => u.UserFriends)
                        .HasForeignKey(r => r.UserFriendId)
                        .WillCascadeOnDelete(false);
         
        

        }
        public DbSet<TypeEvent> TypeEvents { get; set; }
        public DbSet<Status> Statuses { get; set; }

        public DbSet<EventModel> EventModels { get; set; }
        public DbSet<ContributionType> ContributionTypes { get; set; }
        public DbSet<Contribution> Contributions { get; set; }
        public DbSet<Relationship> Relationships { get; set; }

        
    }
    public class IdentityManager
    {
      


        public bool CreateRole(string name)
        {
            var rm = new RoleManager<IdentityRole>(
                new RoleStore<IdentityRole>(new ApplicationDbContext()));
            var idResult = rm.Create(new IdentityRole(name));
            return idResult.Succeeded;
        }


     


        public bool AddUserToRole(String userId, string roleName)
        {
            var um = new UserManager<ApplicationUser>(
                new UserStore<ApplicationUser>(new ApplicationDbContext()));
            var idResult = um.AddToRole(userId, roleName);
            return idResult.Succeeded;
        }

        public bool RoleExists(string name)
        {
            var rm = new RoleManager<IdentityRole>(
                new RoleStore<IdentityRole>(new ApplicationDbContext()));
            return rm.RoleExists(name);
        }
        public void ClearUserRoles(string userId)
        {
            var um = new UserManager<ApplicationUser>(
                new UserStore<ApplicationUser>(new ApplicationDbContext()));
            var user = um.FindById(userId);
            var currentRoles = new List<IdentityUserRole>();
            currentRoles.AddRange(user.Roles);
            foreach (var role in currentRoles)
            {
                um.RemoveFromRole(userId, role.Role.Name);
            }
        }
    }
  
}