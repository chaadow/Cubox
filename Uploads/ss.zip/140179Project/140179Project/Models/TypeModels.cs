﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace _140179Project.Models
{
    public class TypeEvent
    {
        public int ID { get; set; }
        public string TypeName { get; set; }

        public virtual List<EventModel> EventModels { get; set; }
    } 
    public class ContributionType
    {
        public int ID { get; set; }
        public string name { get; set; }

        public virtual List<Contribution> Contributions { get; set; } 
    }

 
}