﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using _140179Project.Models;

namespace _140179Project.Controllers
{
    public class ContributionController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: /Contribution/
        public async Task<ActionResult> Index()
        {
            var contributions = db.Contributions.Include(c => c.ContributionType).Include(c => c.EventModel);
            return View(await contributions.ToListAsync());
        }

        // GET: /Contribution/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Contribution contribution = await db.Contributions.FindAsync(id);
            if (contribution == null)
            {
                return HttpNotFound();
            }
            return View(contribution);
        }

        // GET: /Contribution/Create
        public ActionResult Create()
        {
            ViewBag.ContributionTypeId = new SelectList(db.ContributionTypes, "ID", "name");
            ViewBag.EventModelId = new SelectList(db.EventModels, "ID", "Name");
            return View();
        }

        // POST: /Contribution/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include="ID,Name,Quantity,ContributionTypeId,EventModelId")] Contribution contribution)
        {
            if (ModelState.IsValid)
            {
                db.Contributions.Add(contribution);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            ViewBag.ContributionTypeId = new SelectList(db.ContributionTypes, "ID", "name", contribution.ContributionTypeId);
            ViewBag.EventModelId = new SelectList(db.EventModels, "ID", "Name", contribution.EventModelId);
            return View(contribution);
        }

        // GET: /Contribution/Edit/5
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Contribution contribution = await db.Contributions.FindAsync(id);
            if (contribution == null)
            {
                return HttpNotFound();
            }
            ViewBag.ContributionTypeId = new SelectList(db.ContributionTypes, "ID", "name", contribution.ContributionTypeId);
            ViewBag.EventModelId = new SelectList(db.EventModels, "ID", "Name", contribution.EventModelId);
            return View(contribution);
        }

        // POST: /Contribution/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include="ID,Name,Quantity,ContributionTypeId,EventModelId")] Contribution contribution)
        {
            if (ModelState.IsValid)
            {
                db.Entry(contribution).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            ViewBag.ContributionTypeId = new SelectList(db.ContributionTypes, "ID", "name", contribution.ContributionTypeId);
            ViewBag.EventModelId = new SelectList(db.EventModels, "ID", "Name", contribution.EventModelId);
            return View(contribution);
        }

        // GET: /Contribution/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Contribution contribution = await db.Contributions.FindAsync(id);
            if (contribution == null)
            {
                return HttpNotFound();
            }
            return View(contribution);
        }

        // POST: /Contribution/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            Contribution contribution = await db.Contributions.FindAsync(id);
            db.Contributions.Remove(contribution);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
