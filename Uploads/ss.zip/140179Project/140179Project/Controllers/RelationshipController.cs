﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using _140179Project.Models;

namespace _140179Project.Controllers
{
    public class RelationshipController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();
        private UserManager<ApplicationUser> myManager;

        public RelationshipController() 
        {
         myManager= new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(db));
        }

        // GET: /Relationship/
        public async Task<ActionResult> Index()
        {
            var myCurrentUser = myManager.FindById(User.Identity.GetUserId());
            var relationships = db.Relationships.Include(r => r.User).Include(r => r.UserFriend);
            return View(db.Relationships.ToList().Where(relation => relation.User == myCurrentUser));
        }

        // GET: /Relationship/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Relationship relationship = await db.Relationships.FindAsync(id);
            if (relationship == null)
            {
                return HttpNotFound();
            }
            return View(relationship);
        }

        // GET: /Relationship/Create
        public ActionResult Create()
        {
            ViewBag.UserId = new SelectList(db.Users, "Id", "UserName");
            ViewBag.UserFriendId = new SelectList(db.Users, "Id", "UserName");
            return View();
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include="ID,UserId,UserFriendId")] Relationship relationship)
        {
          
            if (ModelState.IsValid)
            {
                db.Relationships.Add(relationship);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            ViewBag.UserId = new SelectList(db.Users, "Id", "UserName", relationship.UserId);
            ViewBag.UserFriendId = new SelectList(db.Users, "Id", "UserName", relationship.UserFriendId);
            return View(relationship);
        }

        public ActionResult Users(string search)
        {
            var model = new List<EditUserViewModel>();
            bool isAdmin = false;
            var result = from s in db.Users
                           select s;
            
            if (!String.IsNullOrEmpty(search))
            {
                result = result.Where(u => u.UserName.ToUpper().Contains(search.ToUpper())
                                           || u.FirstName.ToUpper().Contains(search.ToUpper())
                                           || u.LastName.ToUpper().Contains(search.ToUpper()));
                

                foreach (var user in result)
                {
                    if (User.Identity.GetUserName().Equals(user.UserName))
                    {
                        continue;
                    }
                    foreach (var role in user.Roles)
                    {
                        if (role.Role.Name.Equals("Admin"))
                        {
                            isAdmin = true;
                            break;
                        }



                    }
                    if (isAdmin)
                    {

                        isAdmin = false;
                        continue;
                    }
                    var u = new EditUserViewModel(user);
                    model.Add(u);
                }
            }
            else
            {
               
                var users = db.Users;
                foreach (var user in users)
                {
                    if (User.Identity.GetUserName().Equals(user.UserName))
                    {
                        continue;
                    }
                    foreach (var role in user.Roles)
                    {
                        if (role.Role.Name.Equals("Admin"))
                        {
                            isAdmin = true;
                            break;
                        }



                    }
                    if (isAdmin)
                    {

                        isAdmin = false;
                        continue;
                    }
                    var u = new EditUserViewModel(user);
                    model.Add(u);
                }
            }
            
            
           
            return View(model);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddFriend(string hello)
        {
            var relationship = new Relationship();
            relationship.UserId = User.Identity.GetUserId();
            var friend = db.Users.First(u => u.UserName == hello);

            relationship.UserFriendId = friend.Id;
                db.Relationships.Add(relationship);
                db.SaveChanges();
                return RedirectToAction("Index");
            

            //ViewBag.UserId = new SelectList(db.Users, "Id", "UserName", relationship.UserId);
            //ViewBag.UserFriendId = new SelectList(db.Users, "Id", "UserName", relationship.UserFriendId);
            //return View(relationship);
        }


        // GET: /Relationship/Edit/5
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Relationship relationship = await db.Relationships.FindAsync(id);
            if (relationship == null)
            {
                return HttpNotFound();
            }
            ViewBag.UserId = new SelectList(db.Users, "Id", "UserName", relationship.UserId);
            ViewBag.UserFriendId = new SelectList(db.Users, "Id", "UserName", relationship.UserFriendId);
            return View(relationship);
        }

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include="ID,UserId,UserFriendId")] Relationship relationship)
        {
            if (ModelState.IsValid)
            {
                db.Entry(relationship).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            ViewBag.UserId = new SelectList(db.Users, "Id", "UserName", relationship.UserId);
            ViewBag.UserFriendId = new SelectList(db.Users, "Id", "UserName", relationship.UserFriendId);
            return View(relationship);
        }

        // GET: /Relationship/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Relationship relationship = await db.Relationships.FindAsync(id);
            if (relationship == null)
            {
                return HttpNotFound();
            }
            return View(relationship);
        }

        // POST: /Relationship/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            Relationship relationship = await db.Relationships.FindAsync(id);
            db.Relationships.Remove(relationship);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
