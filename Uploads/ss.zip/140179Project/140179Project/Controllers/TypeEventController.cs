﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using _140179Project.Models;

namespace _140179Project.Controllers
{
    public class TypeEventController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: /TypeEvent/
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult> Index()
        {
            return View(await db.TypeEvents.ToListAsync());
        }
        [Authorize(Roles = "Admin")]
        // GET: /TypeEvent/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TypeEvent typeevent = await db.TypeEvents.FindAsync(id);
            if (typeevent == null)
            {
                return HttpNotFound();
            }
            return View(typeevent);
        }
        [Authorize(Roles = "Admin")]
        // GET: /TypeEvent/Create
        public ActionResult Create()
        {
            return View();
        }

       [Authorize(Roles = "Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include="ID,TypeName")] TypeEvent typeevent)
        {
            if (ModelState.IsValid)
            {
                db.TypeEvents.Add(typeevent);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(typeevent);
        }

        [Authorize(Roles = "Admin")]
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TypeEvent typeevent = await db.TypeEvents.FindAsync(id);
            if (typeevent == null)
            {
                return HttpNotFound();
            }
            return View(typeevent);
        }

       [Authorize(Roles = "Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include="ID,TypeName")] TypeEvent typeevent)
        {
            if (ModelState.IsValid)
            {
                db.Entry(typeevent).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(typeevent);
        }

       [Authorize(Roles = "Admin")]
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TypeEvent typeevent = await db.TypeEvents.FindAsync(id);
            if (typeevent == null)
            {
                return HttpNotFound();
            }
            return View(typeevent);
        }

       [Authorize(Roles = "Admin")]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            TypeEvent typeevent = await db.TypeEvents.FindAsync(id);
            db.TypeEvents.Remove(typeevent);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
