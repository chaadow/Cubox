﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using _140179Project.Models;

namespace _140179Project.Controllers
{
    public class ContributionTypeController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

       [Authorize(Roles = "Admin")]
        public async Task<ActionResult> Index()
        {
            return View(await db.ContributionTypes.ToListAsync());
        }

        [Authorize(Roles = "Admin")]
       
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ContributionType contributiontype = await db.ContributionTypes.FindAsync(id);
            if (contributiontype == null)
            {
                return HttpNotFound();
            }
            return View(contributiontype);
        }

       [Authorize(Roles = "Admin")]
        public ActionResult Create()
        {
            return View();
        }

       [Authorize(Roles = "Admin")]
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include="ID,name")] ContributionType contributiontype)
        {
            if (ModelState.IsValid)
            {
                db.ContributionTypes.Add(contributiontype);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(contributiontype);
        }

       [Authorize(Roles = "Admin")]
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ContributionType contributiontype = await db.ContributionTypes.FindAsync(id);
            if (contributiontype == null)
            {
                return HttpNotFound();
            }
            return View(contributiontype);
        }

[Authorize(Roles = "Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include="ID,name")] ContributionType contributiontype)
        {
            if (ModelState.IsValid)
            {
                db.Entry(contributiontype).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(contributiontype);
        }

      [Authorize(Roles = "Admin")]
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ContributionType contributiontype = await db.ContributionTypes.FindAsync(id);
            if (contributiontype == null)
            {
                return HttpNotFound();
            }
            return View(contributiontype);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            ContributionType contributiontype = await db.ContributionTypes.FindAsync(id);
            db.ContributionTypes.Remove(contributiontype);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
