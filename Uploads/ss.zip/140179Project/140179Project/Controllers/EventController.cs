﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using _140179Project.Models;

namespace _140179Project.Controllers
{
    public class EventController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();
        private UserManager<ApplicationUser> myManager;

        public EventController()
        {
            myManager= new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(db));
        }

        // GET: /Event/
        public async Task<ActionResult> Index()
        {
            var myCurrentUser = myManager.FindById(User.Identity.GetUserId());

            return View( db.EventModels.ToList().Where(currentevents => currentevents.ApplicationUser == myCurrentUser ));
        }

        // GET: /Event/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EventModel eventmodel = await db.EventModels.FindAsync(id);
            if (eventmodel == null)
            {
                return HttpNotFound();
            }
            return View(eventmodel);
        }

        // GET: /Event/Create
        public ActionResult Create()
        {
            var typeList = new List<string>();

            var typeQuery = from d in db.TypeEvents
                           orderby d.TypeName
                           select d.TypeName;

           //typeList.AddRange(typeQuery.Distinct());
         //  ViewBag.TypeEvent = new SelectList(typeList);
            ViewBag.TypeEvent = new SelectList(from t in db.TypeEvents select t, "ID", "TypeName");
            return View();
        }

        // POST: /Event/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include="ID,Name,Address,Description,DateTime,TypeEventId")] EventModel eventmodel)
        {

            if (ModelState.IsValid)
            {
                var myCurrentUser = myManager.FindById(User.Identity.GetUserId());
                var defaultStatus = db.Statuses.Find(1);
                eventmodel.Status = defaultStatus;
                //Debug.WriteLine(eventmodel.TypeEvent);

                eventmodel.ApplicationUser = myCurrentUser;
                db.EventModels.Add(eventmodel);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(eventmodel);
        }

        // GET: /Event/Edit/5
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EventModel eventmodel = await db.EventModels.FindAsync(id);
            if (eventmodel == null)
            {
                return HttpNotFound();
            }
            return View(eventmodel);
        }

        // POST: /Event/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include="ID,Name,Address,Description,DateTime")] EventModel eventmodel)
        {
            if (ModelState.IsValid)
            {
                db.Entry(eventmodel).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(eventmodel);
        }

        // GET: /Event/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EventModel eventmodel = await db.EventModels.FindAsync(id);
            if (eventmodel == null)
            {
                return HttpNotFound();
            }
            return View(eventmodel);
        }

        // POST: /Event/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            EventModel eventmodel = await db.EventModels.FindAsync(id);
            db.EventModels.Remove(eventmodel);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        [Authorize(Roles = "Admin")]

        public async Task<ActionResult> DashBoard()
        {
            return View(await db.EventModels.ToListAsync());
        }

        public async Task<ActionResult> EditAdmin(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            
            EventModel eventmodel = await db.EventModels.FindAsync(id);
            if (eventmodel == null)
            {
                return HttpNotFound();
            }
            ViewBag.StatusList = new SelectList(db.Statuses, "ID", "name" );
;            return View(eventmodel);
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> EditAdmin([Bind(Include = "ID,Name,Address,Description,DateTime,StatusId,TypeEventId")] EventModel eventmodel)
        {
            if (ModelState.IsValid)
            {
                db.Entry(eventmodel).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("DashBoard");
            }
            return View(eventmodel);
        }
    }
}
